<?php

namespace ClassyLlama\AvaTax\Api\Framework\Interaction\Request;

/**
 * Interface RequestInterface
 * @package ClassyLlama\AvaTax\Api\Framework\Interaction\Request
 */
interface RequestInterface
{
}
