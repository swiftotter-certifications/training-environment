<?php

namespace ClassyLlama\AvaTax\Api;

/**
 * Marker interface
 *
 * Interface UiComponentV1Interface
 * @package ClassyLlama\AvaTax\Api
 */
interface UiComponentV1Interface
{
}
