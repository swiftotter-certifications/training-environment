<?php

namespace ClassyLlama\AvaTax\Api;

/**
 * Marker interface
 *
 * Interface UiComponentV2Interface
 * @package ClassyLlama\AvaTax\Api
 */
interface UiComponentV2Interface
{
}
