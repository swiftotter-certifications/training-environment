<?php
/**
 * ClassyLlama_AvaTax
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Open Software License (OSL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/osl-3.0.php
 *
 * @copyright  Copyright (c) 2018 Avalara, Inc.
 * @license    http://opensource.org/licenses/osl-3.0.php Open Software License (OSL 3.0)
 */

namespace ClassyLlama\AvaTax\Helper;

use Magento\Framework\App\Helper\AbstractHelper;
use Magento\Framework\App\Helper\Context;
use ClassyLlama\AvaTax\BaseProvider\Logger\GenericLogger;
use ClassyLlama\AvaTax\Framework\AppInterface;

class ApiLog extends AbstractHelper
{
    const CONNECTOR_ID = 'a0o5a000007TuRvAAK';

    const CONNECTOR_STRING = AppInterface::CONNECTOR_STRING;

    const CONNECTOR_NAME = AppInterface::APP_NAME;

    const HTML_ESCAPE_PATTERN = '/<(.*) ?.*>(.*)<\/(.*)>/';                         

    /**
     * @var Config
     */
    protected $config;

    /**
     * @var GenericLogger
     */
    protected $genericLogger;

    /**
     * @param Config  $config
     * @param Context $context
     * @param GenericLogger $genericLogger
     */
    public function __construct(Config $config, Context $context, GenericLogger $genericLogger)
    {
        parent::__construct($context);

        $this->config = $config;
        $this->genericLogger = $genericLogger;
    }

    /**
     * API Logging
     *
     * @param string $message
     * @param array $context
     * @param $scopeId|Null
     * @param $scopeType|Null
     * @return void
     */
    public function apiLog(string $message, array $context = [], $scopeId = null, $scopeType = null)
    {
        if (strlen($message) > 0) {
            $isProduction = $this->config->isProductionMode($scopeId, $scopeType);
            $accountNumber = $this->config->getAccountNumber($scopeId, $scopeType, $isProduction);
            $accountSecret = $this->config->getLicenseKey($scopeId, $scopeType, $isProduction);
            $connectorId = self::CONNECTOR_ID;
            $clientString = self::CONNECTOR_STRING;
            $mode = $isProduction ? \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_MODE_PRODUCTION : \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_MODE_SANDBOX;
            $connectorName = self::CONNECTOR_NAME;
            $source = isset($context['config']['source']) ? $context['config']['source'] : 'MagentoPage';
            $operation = isset($context['config']['operation']) ? $context['config']['operation'] : 'MagentoOperation';
            $logType = isset($context['config']['log_type']) ? $context['config']['log_type'] : \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_LOG_TYPE_DEBUG;
            $logLevel = isset($context['config']['log_level']) ? $context['config']['log_level'] : \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_LOG_LEVEL_INFO;
            $functionName = isset($context['config']['function_name']) ? $context['config']['function_name'] : __METHOD__;
            
            $params = [
                'config' => [
                    'account_number' => $accountNumber,
                    'account_secret' => $accountSecret,
                    'connector_id' => $connectorId,
                    'client_string' => $clientString,
                    'mode' => $mode,
                    'connector_name' => $connectorName,
                    'connector_version' => $clientString,
                    'source' => $source,
                    'operation' => $operation,
                    'log_type' => $logType,
                    'log_level' => $logLevel,
                    'function_name' => $functionName,
                    'extra_params' => isset($context['config']['extra_params']) ? $context['config']['extra_params'] : []
                ]
            ];

            $this->genericLogger->apiLog($message, [$params]);
        }
    }

    /**
     * Log Connection with AvaTax
     *
     * @param string $message
     * @param $scopeId
     * @param $scopeType
     * @return void
     */
    public function testConnectionLog(string $message, $scopeId, $scopeType)
    {
        try {
            $source = 'ConfigurationPage';
            $operation = 'Test Connection';
            $logType = \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_LOG_TYPE_CONFIG;
            $logLevel = \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_LOG_LEVEL_INFO;
            $functionName = __METHOD__;
            $context = [
                'config' => [
                    'source' => $source,
                    'operation' => $operation,
                    'log_type' => $logType,
                    'log_level' => $logLevel,
                    'function_name' => $functionName
                ]
            ];
            $this->apiLog($message, $context, $scopeId, $scopeType);
        } catch(\Exception $e) {
            //do nothing as this is internal logging
        }
    }

    /**
     * configSaveLog API Logging
     *
     * @param $scopeId
     * @param $scopeType
     * @return void
     */
    public function configSaveLog($scopeId, $scopeType)
    {
        try {
            $message = "";
            $source = 'ConfigurationPage';
            $operation = 'ConfigChanges';
            $logType = \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_LOG_TYPE_CONFIG;
            $logLevel = \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_LOG_LEVEL_INFO;
            $functionName = __METHOD__;
            $context = [
                'config' => [
                    'source' => $source,
                    'operation' => $operation,
                    'log_type' => $logType,
                    'log_level' => $logLevel,
                    'function_name' => $functionName
                ]
            ];
            $data = $this->getConfigData($scopeId, $scopeType);
            $message = json_encode($data);
            $this->apiLog($message, $context, $scopeId, $scopeType);
        } catch(\Exception $e) {
            //do nothing as this is internal logging
        }
    }

    /**
     * TransactionRequest API Logging
     *
     * @param array $logContext
     * @param $scopeId
     * @param $scopeType
     * @return void
     */
    public function makeTransactionRequestLog(array $logContext, $scopeId, $scopeType)
    {
        try {
            $message = "Transaction Request Log";
            $source = isset($logContext['source']) ? $logContext['source'] : 'TransactionPage';
            $operation = isset($logContext['operation']) ? $logContext['operation'] : 'TransactionOperation';
            $logType = \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_LOG_TYPE_PERFORMANCE;
            $logLevel = \ClassyLlama\AvaTax\BaseProvider\Helper\Generic\Config::API_LOG_LEVEL_INFO;
            $functionName = isset($logContext['function_name']) ? $logContext['function_name'] : __METHOD__;
            if (isset($logContext['extra']['ConnectorTime']) && isset($logContext['extra']['ConnectorLatency']) ) {
                list($connectorTime, $latencyTime) = $this->getLatencyTimeAndConnectorTime($logContext['extra']);
                unset($logContext['extra']['ConnectorTime']);
                unset($logContext['extra']['ConnectorLatency']);
                if (!is_null($connectorTime))
                    $logContext['extra']['ConnectorTime'] = number_format($connectorTime, 2, '.', ',');
                if (!is_null($latencyTime))
                    $logContext['extra']['ConnectorLatency'] = number_format($latencyTime, 2, '.', ',');
            }
            $context = [
                'config' => [
                    'source' => $source,
                    'operation' => $operation,
                    'log_type' => $logType,
                    'log_level' => $logLevel,
                    'function_name' => $functionName,
                    'extra_params' => isset($logContext['extra']) ? $logContext['extra'] : []
                ]
            ];
            $this->apiLog($message, $context, $scopeId, $scopeType);
        } catch(\Exception $e) {
            //do nothing as this is internal logging
        }
    }

    /**
     * getConfigData function
     *
     * @param $scopeId
     * @param $scopeType
     * @return array
     */
    private function getConfigData($store)
    {
        $configPaths = [
            "AvaTax - General" => "tax/avatax",  
            "AvaTax - Customs" => "tax/avatax_customs",
            "AvaTax - Document Management" => "tax/avatax_document_management", 
            "AvaTax - Certificate Capture Management" => "tax/avatax_certificate_capture",
            "AvaTax - Advanced" => "tax/avatax_advanced"
        ];

        foreach ($configPaths as $title=>$path) {
            $groupData = $this->config->getConfigData($path, $store);
            $data[$title] = $this->escapeAvaTaxData($groupData);
        }

        if (isset($data["AvaTax - General"]["production_license_key"])) {
            unset($data["AvaTax - General"]["production_license_key"]);
        }

        if (isset($data["AvaTax - General"]["development_license_key"])) {
            unset($data["AvaTax - General"]["development_license_key"]);
        }
        
        return $data;
    }

    /**
     * escapeAvaTaxData function
     *
     * @param array $data
     * @return array
     */
    public function escapeAvaTaxData(array $data)
    {
        if (empty($data)) {
            return $data;
        }
        foreach ($data as $key=>&$value) {
            if (is_array($value)) {
                $value = $this->escapeAvaTaxData($value);
            } else {
                /* To Exclude html value from log */
                if (preg_match(self::HTML_ESCAPE_PATTERN, $value)) {
                    unset($data[$key]);
                }
            }
        }

        return $data;
    }

    /**
     * getLatencyTimeAndConnectorTime function
     *
     * @param array $logContext
     * @return array
     */
    public function getLatencyTimeAndConnectorTime(array $logContext)
    {
        $latencyTime = null;
        $connectorTime = null;
        $isSufficientData = 0;
        if (empty($logContext)) {
            return [$latencyTime, $connectorTime];
        }
        if (isset($logContext['ConnectorTime']['start'])) {
            $isSufficientData++;
        }
        if (isset($logContext['ConnectorTime']['end'])) {
            $isSufficientData++;
        }
        if (isset($logContext['ConnectorLatency']['end'])) {
            $isSufficientData++;
        }
        if (isset($logContext['ConnectorLatency']['end'])) {
            $isSufficientData++;
        }
        if ($isSufficientData < 4) {
            return [$latencyTime, $connectorTime];
        }
        $connectorTime = $logContext['ConnectorTime']['end'] - $logContext['ConnectorTime']['start'];
        $latencyTime = $logContext['ConnectorLatency']['end'] - $logContext['ConnectorLatency']['start'];
        if ($latencyTime < 0) {
            $latencyTime = 0;
        }
        $connectorTime = $connectorTime - $latencyTime;
        return [$latencyTime, $connectorTime];
    }
}