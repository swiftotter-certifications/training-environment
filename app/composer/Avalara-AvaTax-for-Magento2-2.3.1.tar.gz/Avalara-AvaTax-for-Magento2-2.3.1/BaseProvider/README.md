# Magento 2 Avalara Base Provider Extension

This extesion is for BaseProvider utility features like Queue etc...

# Documentation

# License

This project is licensed under the Open Software License 3.0 (OSL-3.0). See included LICENSE file for full text of OSL-3.0

# Support

Contact Avalara for any support requests, either via [their support email](support@avalara.com) or via [this page](https://salestax.avalara.com/contact-us/).
