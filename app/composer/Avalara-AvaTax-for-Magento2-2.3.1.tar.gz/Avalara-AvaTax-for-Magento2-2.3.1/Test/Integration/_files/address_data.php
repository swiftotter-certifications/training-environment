<?php declare(strict_types=1);

return [
    'region' => 'CA',
    'region_id' => '12',
    'postcode' => '123-456',
    'lastname' => 'lastname',
    'firstname' => 'firstname',
    'street' => 'street',
    'city' => 'Los Angeles',
    'email' => 'admin@example.com',
    'telephone' => '11111111',
    'country_id' => 'US'
];
